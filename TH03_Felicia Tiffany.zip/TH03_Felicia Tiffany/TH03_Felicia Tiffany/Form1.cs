﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;

namespace TH03_Felicia_Tiffany
{
    public partial class Login : Form
    {
        DataTable dtBank = new DataTable();
        int input;

        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            dtBank.Columns.Add("Username");
            dtBank.Columns.Add("Password");
            dtBank.Columns.Add("Saldo");
        }

        private void bt_signup_Click(object sender, EventArgs e)
        {
            p_login.Visible = false;
            p_register.Visible = true;
        }

        private void bt_regis_Click(object sender, EventArgs e)
        {
            int countsama = 0;
            for (int i = 0; i < dtBank.Rows.Count; i++)
            {
                if (dtBank.Rows[i][0].ToString() == tb_userregis.Text)
                {
                    countsama++;
                }
            }
            if (countsama == 0)
            {
                dtBank.Rows.Add(tb_userregis.Text, tb_passregis.Text, "0");
                MessageBox.Show("Register Succesful");
                tb_userregis.Text = ""; tb_passregis.Text = "";
                p_register.Visible = false;
                p_login.Visible = true;
            }
            else if (countsama >= 1)
            {
                MessageBox.Show("Username has been used");
            }
        }

        private void bt_login_Click(object sender, EventArgs e)
        {
            bool ada = false;
            if (dtBank.Rows.Count == 0)
            {
                MessageBox.Show("Error");
            }
            else
            {
                for (int i = 0; i < dtBank.Rows.Count; i++)
                {
                    if (dtBank.Rows[i][0].ToString() == tb_user.Text)
                    {
                        input = i;
                        ada = true;
                    }
                }
                if (dtBank.Rows[input][1].ToString() == tb_pass.Text && ada == true)
                {
                    MessageBox.Show("Login Succesful");
                    tb_user.Text = ""; tb_pass.Text = "";
                    int uang = Convert.ToInt32(dtBank.Rows[input][2]);
                    lbl_saldo.Text = "Rp " + uang.ToString("N");
                    p_login.Visible = false;
                    p_main.Visible = true;
                    bt_logout.Visible = true;
                }
                else
                {
                    MessageBox.Show("Wrong Password");
                }
            }
        }

        private void bt_deposit_Click(object sender, EventArgs e)
        {
            p_main.Visible = false;
            p_setor.Visible = true;
        }

        private void bt_setor_Click(object sender, EventArgs e)
        {
            if (tb_setor.Text == "")
            {
                MessageBox.Show("Error");
            }
            else
            {
                Setor(Convert.ToInt64(tb_setor.Text));
            }
            long uang = Convert.ToInt64(dtBank.Rows[input][2]);
            lbl_saldo.Text = "Rp " + uang.ToString("N");
        }
        private void bt_withdraw_Click(object sender, EventArgs e)
        {
            p_main.Visible = false;
            long uang = Convert.ToInt64(dtBank.Rows[input][2]);
            lbl_saldo2.Text = "Rp " + uang.ToString("N");
            p_tarik1.Visible = true;
        }

        private void bt_tarik_Click(object sender, EventArgs e)
        {
            if (tb_tarik.Text == "")
            {
                MessageBox.Show("Error");
            }
            else
            {
                Tarik(Convert.ToInt64(tb_tarik.Text));
            }
            long uang = Convert.ToInt64(dtBank.Rows[input][2]);
            lbl_saldo.Text = "Rp " + uang.ToString("N");
        }

        private void bt_logout_Click(object sender, EventArgs e)
        {
            p_login.Visible = true;
            p_main.Visible = false;
            p_setor.Visible = false;
            p_tarik1.Visible = false;
            bt_logout.Visible = false;
        }
        private void Setor(long x)
        {
            long saldo = Convert.ToInt64(dtBank.Rows[input][2]);
            if (x >= 1)
            {
                saldo = x + saldo;
                dtBank.Rows[input][2] = saldo;
                MessageBox.Show("Succesfully Add Deposit");
                tb_setor.Text = "";
                p_setor.Visible = false;
                p_main.Visible = true;
            }
            else if (x <= 0)
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
            }
        }
        private void Tarik (long y)
        {
            long saldo = Convert.ToInt64(dtBank.Rows[input][2]);
            if (y > saldo)
            {
                MessageBox.Show("Withdrawal Amount Can't be Larger than The Balance");
            }
            else if (y <= 0)
            {
                MessageBox.Show("Deposit Amount Can't be Less Than 1");
            }
            else if (y <= saldo)
            {
                saldo = saldo - y;
                dtBank.Rows[input][2] = saldo;
                MessageBox.Show("Succesfully Withdraw");
                tb_tarik.Text = "";
                p_tarik1.Visible = false;
                p_main.Visible = true;
            }
        }
    }
}