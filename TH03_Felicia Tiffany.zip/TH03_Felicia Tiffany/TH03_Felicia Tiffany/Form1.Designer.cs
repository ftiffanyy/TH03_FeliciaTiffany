﻿namespace TH03_Felicia_Tiffany
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_user = new System.Windows.Forms.TextBox();
            this.tb_pass = new System.Windows.Forms.TextBox();
            this.bt_login = new System.Windows.Forms.Button();
            this.bt_signup = new System.Windows.Forms.Button();
            this.p_login = new System.Windows.Forms.Panel();
            this.p_register = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.bt_regis = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_userregis = new System.Windows.Forms.TextBox();
            this.tb_passregis = new System.Windows.Forms.TextBox();
            this.bt_logout = new System.Windows.Forms.Button();
            this.p_main = new System.Windows.Forms.Panel();
            this.p_setor = new System.Windows.Forms.Panel();
            this.lbl_saldo2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tb_tarik = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.bt_tarik = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.tb_setor = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.bt_setor = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.bt_withdraw = new System.Windows.Forms.Button();
            this.lbl_saldo = new System.Windows.Forms.Label();
            this.bt_deposit = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.p_tarik1 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.p_login.SuspendLayout();
            this.p_register.SuspendLayout();
            this.p_main.SuspendLayout();
            this.p_setor.SuspendLayout();
            this.p_tarik1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(95, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "UC BANK";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(14, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Username :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(16, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Password :";
            // 
            // tb_user
            // 
            this.tb_user.Location = new System.Drawing.Point(96, 33);
            this.tb_user.Name = "tb_user";
            this.tb_user.Size = new System.Drawing.Size(100, 20);
            this.tb_user.TabIndex = 3;
            // 
            // tb_pass
            // 
            this.tb_pass.Location = new System.Drawing.Point(96, 63);
            this.tb_pass.Name = "tb_pass";
            this.tb_pass.Size = new System.Drawing.Size(100, 20);
            this.tb_pass.TabIndex = 4;
            // 
            // bt_login
            // 
            this.bt_login.Location = new System.Drawing.Point(17, 103);
            this.bt_login.Name = "bt_login";
            this.bt_login.Size = new System.Drawing.Size(81, 28);
            this.bt_login.TabIndex = 5;
            this.bt_login.Text = "Login";
            this.bt_login.UseVisualStyleBackColor = true;
            this.bt_login.Click += new System.EventHandler(this.bt_login_Click);
            // 
            // bt_signup
            // 
            this.bt_signup.Location = new System.Drawing.Point(115, 103);
            this.bt_signup.Name = "bt_signup";
            this.bt_signup.Size = new System.Drawing.Size(81, 28);
            this.bt_signup.TabIndex = 6;
            this.bt_signup.Text = "Sign Up";
            this.bt_signup.UseVisualStyleBackColor = true;
            this.bt_signup.Click += new System.EventHandler(this.bt_signup_Click);
            // 
            // p_login
            // 
            this.p_login.Controls.Add(this.label3);
            this.p_login.Controls.Add(this.bt_signup);
            this.p_login.Controls.Add(this.label2);
            this.p_login.Controls.Add(this.bt_login);
            this.p_login.Controls.Add(this.tb_user);
            this.p_login.Controls.Add(this.tb_pass);
            this.p_login.Location = new System.Drawing.Point(61, 94);
            this.p_login.Name = "p_login";
            this.p_login.Size = new System.Drawing.Size(210, 160);
            this.p_login.TabIndex = 7;
            // 
            // p_register
            // 
            this.p_register.Controls.Add(this.label4);
            this.p_register.Controls.Add(this.bt_regis);
            this.p_register.Controls.Add(this.label5);
            this.p_register.Controls.Add(this.tb_userregis);
            this.p_register.Controls.Add(this.tb_passregis);
            this.p_register.Location = new System.Drawing.Point(61, 94);
            this.p_register.Name = "p_register";
            this.p_register.Size = new System.Drawing.Size(210, 160);
            this.p_register.TabIndex = 8;
            this.p_register.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(16, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Password :";
            // 
            // bt_regis
            // 
            this.bt_regis.Location = new System.Drawing.Point(61, 103);
            this.bt_regis.Name = "bt_regis";
            this.bt_regis.Size = new System.Drawing.Size(81, 28);
            this.bt_regis.TabIndex = 6;
            this.bt_regis.Text = "Register";
            this.bt_regis.UseVisualStyleBackColor = true;
            this.bt_regis.Click += new System.EventHandler(this.bt_regis_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 34);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 16);
            this.label5.TabIndex = 1;
            this.label5.Text = "Username :";
            // 
            // tb_userregis
            // 
            this.tb_userregis.Location = new System.Drawing.Point(96, 33);
            this.tb_userregis.Name = "tb_userregis";
            this.tb_userregis.Size = new System.Drawing.Size(100, 20);
            this.tb_userregis.TabIndex = 3;
            // 
            // tb_passregis
            // 
            this.tb_passregis.Location = new System.Drawing.Point(96, 63);
            this.tb_passregis.Name = "tb_passregis";
            this.tb_passregis.Size = new System.Drawing.Size(100, 20);
            this.tb_passregis.TabIndex = 4;
            // 
            // bt_logout
            // 
            this.bt_logout.Location = new System.Drawing.Point(190, 271);
            this.bt_logout.Name = "bt_logout";
            this.bt_logout.Size = new System.Drawing.Size(81, 28);
            this.bt_logout.TabIndex = 7;
            this.bt_logout.Text = "Log Out";
            this.bt_logout.UseVisualStyleBackColor = true;
            this.bt_logout.Visible = false;
            this.bt_logout.Click += new System.EventHandler(this.bt_logout_Click);
            // 
            // p_main
            // 
            this.p_main.Controls.Add(this.bt_withdraw);
            this.p_main.Controls.Add(this.lbl_saldo);
            this.p_main.Controls.Add(this.bt_deposit);
            this.p_main.Controls.Add(this.label7);
            this.p_main.Location = new System.Drawing.Point(61, 94);
            this.p_main.Name = "p_main";
            this.p_main.Size = new System.Drawing.Size(210, 160);
            this.p_main.TabIndex = 9;
            this.p_main.Visible = false;
            // 
            // p_setor
            // 
            this.p_setor.Controls.Add(this.tb_setor);
            this.p_setor.Controls.Add(this.label6);
            this.p_setor.Controls.Add(this.bt_setor);
            this.p_setor.Controls.Add(this.label8);
            this.p_setor.Location = new System.Drawing.Point(61, 94);
            this.p_setor.Name = "p_setor";
            this.p_setor.Size = new System.Drawing.Size(210, 160);
            this.p_setor.TabIndex = 10;
            this.p_setor.Visible = false;
            // 
            // lbl_saldo2
            // 
            this.lbl_saldo2.AutoSize = true;
            this.lbl_saldo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saldo2.Location = new System.Drawing.Point(87, 18);
            this.lbl_saldo2.Name = "lbl_saldo2";
            this.lbl_saldo2.Size = new System.Drawing.Size(0, 16);
            this.lbl_saldo2.TabIndex = 10;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(23, 18);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(66, 16);
            this.label11.TabIndex = 9;
            this.label11.Text = "Balance : ";
            // 
            // tb_tarik
            // 
            this.tb_tarik.Location = new System.Drawing.Point(47, 74);
            this.tb_tarik.Name = "tb_tarik";
            this.tb_tarik.Size = new System.Drawing.Size(109, 20);
            this.tb_tarik.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(81, 34);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 16);
            this.label9.TabIndex = 7;
            // 
            // bt_tarik
            // 
            this.bt_tarik.Location = new System.Drawing.Point(59, 104);
            this.bt_tarik.Name = "bt_tarik";
            this.bt_tarik.Size = new System.Drawing.Size(81, 28);
            this.bt_tarik.TabIndex = 6;
            this.bt_tarik.Text = "Withdraw";
            this.bt_tarik.UseVisualStyleBackColor = true;
            this.bt_tarik.Click += new System.EventHandler(this.bt_tarik_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(23, 47);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(161, 16);
            this.label10.TabIndex = 1;
            this.label10.Text = "Input Withdrawal Amount : ";
            // 
            // tb_setor
            // 
            this.tb_setor.Location = new System.Drawing.Point(49, 69);
            this.tb_setor.Name = "tb_setor";
            this.tb_setor.Size = new System.Drawing.Size(109, 20);
            this.tb_setor.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(83, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 16);
            this.label6.TabIndex = 7;
            // 
            // bt_setor
            // 
            this.bt_setor.Location = new System.Drawing.Point(61, 103);
            this.bt_setor.Name = "bt_setor";
            this.bt_setor.Size = new System.Drawing.Size(81, 28);
            this.bt_setor.TabIndex = 6;
            this.bt_setor.Text = "Deposit";
            this.bt_setor.UseVisualStyleBackColor = true;
            this.bt_setor.Click += new System.EventHandler(this.bt_setor_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(37, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(142, 16);
            this.label8.TabIndex = 1;
            this.label8.Text = "Input Deposit Amount : ";
            // 
            // bt_withdraw
            // 
            this.bt_withdraw.Location = new System.Drawing.Point(61, 103);
            this.bt_withdraw.Name = "bt_withdraw";
            this.bt_withdraw.Size = new System.Drawing.Size(81, 28);
            this.bt_withdraw.TabIndex = 8;
            this.bt_withdraw.Text = "Withdraw";
            this.bt_withdraw.UseVisualStyleBackColor = true;
            this.bt_withdraw.Click += new System.EventHandler(this.bt_withdraw_Click);
            // 
            // lbl_saldo
            // 
            this.lbl_saldo.AutoSize = true;
            this.lbl_saldo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_saldo.Location = new System.Drawing.Point(83, 34);
            this.lbl_saldo.Name = "lbl_saldo";
            this.lbl_saldo.Size = new System.Drawing.Size(0, 16);
            this.lbl_saldo.TabIndex = 7;
            // 
            // bt_deposit
            // 
            this.bt_deposit.Location = new System.Drawing.Point(61, 69);
            this.bt_deposit.Name = "bt_deposit";
            this.bt_deposit.Size = new System.Drawing.Size(81, 28);
            this.bt_deposit.TabIndex = 6;
            this.bt_deposit.Text = "Deposit";
            this.bt_deposit.UseVisualStyleBackColor = true;
            this.bt_deposit.Click += new System.EventHandler(this.bt_deposit_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(14, 34);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(63, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "Balance :";
            // 
            // p_tarik1
            // 
            this.p_tarik1.Controls.Add(this.lbl_saldo2);
            this.p_tarik1.Controls.Add(this.label12);
            this.p_tarik1.Controls.Add(this.label11);
            this.p_tarik1.Controls.Add(this.tb_tarik);
            this.p_tarik1.Controls.Add(this.label10);
            this.p_tarik1.Controls.Add(this.label9);
            this.p_tarik1.Controls.Add(this.bt_tarik);
            this.p_tarik1.Location = new System.Drawing.Point(61, 94);
            this.p_tarik1.Name = "p_tarik1";
            this.p_tarik1.Size = new System.Drawing.Size(210, 160);
            this.p_tarik1.TabIndex = 11;
            this.p_tarik1.Visible = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(83, 34);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 16);
            this.label12.TabIndex = 7;
            // 
            // Login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 311);
            this.Controls.Add(this.p_tarik1);
            this.Controls.Add(this.p_setor);
            this.Controls.Add(this.p_main);
            this.Controls.Add(this.bt_logout);
            this.Controls.Add(this.p_register);
            this.Controls.Add(this.p_login);
            this.Controls.Add(this.label1);
            this.Name = "Login";
            this.Text = "Login";
            this.Load += new System.EventHandler(this.Login_Load);
            this.p_login.ResumeLayout(false);
            this.p_login.PerformLayout();
            this.p_register.ResumeLayout(false);
            this.p_register.PerformLayout();
            this.p_main.ResumeLayout(false);
            this.p_main.PerformLayout();
            this.p_setor.ResumeLayout(false);
            this.p_setor.PerformLayout();
            this.p_tarik1.ResumeLayout(false);
            this.p_tarik1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_user;
        private System.Windows.Forms.TextBox tb_pass;
        private System.Windows.Forms.Button bt_login;
        private System.Windows.Forms.Button bt_signup;
        private System.Windows.Forms.Panel p_login;
        private System.Windows.Forms.Panel p_register;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button bt_regis;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_userregis;
        private System.Windows.Forms.TextBox tb_passregis;
        private System.Windows.Forms.Button bt_logout;
        private System.Windows.Forms.Panel p_main;
        private System.Windows.Forms.Button bt_deposit;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button bt_withdraw;
        private System.Windows.Forms.Label lbl_saldo;
        private System.Windows.Forms.Panel p_setor;
        private System.Windows.Forms.TextBox tb_setor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button bt_setor;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbl_saldo2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tb_tarik;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button bt_tarik;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel p_tarik1;
        private System.Windows.Forms.Label label12;
    }
}

